<?php
define( 'WP_CACHE', true );
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * Localized language
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u806441573_KE2N4' );

/** Database username */
define( 'DB_USER', 'u806441573_3siql' );

/** Database password */
define( 'DB_PASSWORD', 'V7bVrjCuyC' );

/** Database hostname */
define( 'DB_HOST', '127.0.0.1' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          'n]C3r8`[bkTtW/Rd4r[o:HR6i{5va6E;X@g#gh={34Thrl23B|+7Y:-sPFQ8H+E*' );
define( 'SECURE_AUTH_KEY',   'rma,p1uw78w1g9wp^~&-L] @B)(wvl%M19Up.Rp&Q}!6Dr$/.xsVAEx*%^W%;c6r' );
define( 'LOGGED_IN_KEY',     'J,,wY:XmOBHUG)#kV4luWf?s<EEvjp9)-]|tZRPB UIb8k~9ix!Et@QP>,*<k_a|' );
define( 'NONCE_KEY',         '.BNZ{7S<*;s_)9}F5*UGpE[L9O75a7#O,BTQEctext~MekJ/u;uj#fAMRxe2-p-E' );
define( 'AUTH_SALT',         'IT9AV5Hnb+V]BoqnMdCVWAw/4gD@Vu<%~SlwUP:p|=*a*.v@%x,={}ixq[It#&Zc' );
define( 'SECURE_AUTH_SALT',  'zEl}Wul~X1i`P1k5SsrN>)]&B>JbCYNS0 sJ|-t>iA6,d:xj7p{t9jWNDie0tPv>' );
define( 'LOGGED_IN_SALT',    '8C7Zi#EwLd!``w]fsjX1`X?%Z]^y1h%t[ak&kU8{Z}LOiZyw]w)pcoE!d.{-kO%k' );
define( 'NONCE_SALT',        '}rpG:wy*L>s6+3zD+8X,3{hVE9&wh{t6VTUkyk]PHi@D2JaENY#o<eY).h{lde+3' );
define( 'WP_CACHE_KEY_SALT', ')/^6r( 70 D_g@88dIqNo+01/Fx2(IYTpU z8K ;_y>!@)Il;Ow*D*OM/!k8ph1 ' );


/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';


/* Add any custom values between this line and the "stop editing" line. */



/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
if ( ! defined( 'WP_DEBUG' ) ) {
	define( 'WP_DEBUG', false );
}

define( 'FS_METHOD', 'direct' );
define( 'COOKIEHASH', '371f885e919bbdab3449e47a72d93680' );
define( 'WP_AUTO_UPDATE_CORE', false );
/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
