<?php
	/*
	*Template Name: Home Template
	*/ 
?>
<!doctype html>
<html <?php language_attributes(); ?> <?php twentytwentyone_the_html_classes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="icon" href="https://wordpress-487847-1794651.cloudwaysapps.com/wp-content/uploads/2021/03/fav.jpg" type="image/jpg" sizes="30x30">
	<?php wp_head(); ?>
	<style>
		.bg{
    width: 100%;
    height: 100vh;
    background-size: cover !important;
    background-position: bottom center !important;
}
		@media (max-width: 477px){
	body {
    padding: 50px 30px;
    height: 100vh;
    background-color: #957254;
    display: flex;
    align-items: center; background-image: linear-gradient(#78580f, #000);
	
}
	.bg {
    width: 100%;
    height: 85%;
    background-size: cover !important;
    background-position: bottom center !important;
    border: 2px solid #78580f;
    border-radius: 7px;	 
		
}
		}
		</style>
</head> 
<?php
	 while ( have_posts() ) : the_post();
    $homefeaturedimage = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' ); 
 ?> 
<body >
	<div class='bg' style='background:url(<?php echo $homefeaturedimage[0];?>)'>
	</div>
	<?php
	endwhile;  
	
	?>
	<?php wp_footer(); ?>

</body>
</html>